library(dplyr)
library(shiny)
library(ggplot2)
library(reshape2)
library(DESeq2)

dat <- readRDS(file.path("data/res.rds"))


ui <- fluidPage(
  titlePanel("MSM/SSM Heatmap Plotter"),
  sidebarLayout(
    sidebarPanel(
      textInput(inputId = 'goi',
                label = 'Mouse Genes of Interest',
                value=c('Il10, Cd274, Pdcd1lg2, Tgfb3, Ccl17, Mrc1')),
      checkboxInput(inputId = 'merge_replicates',
                    label = 'Whether to merge biological replicates',
                    value=FALSE),
      checkboxInput(inputId = 'ssm_first',
                    label = 'Order SSM before MSM',
                    value=TRUE),
      checkboxInput(inputId = 'ln_first',
                    label = 'Order LN before TDLN',
                    value=TRUE),
      checkboxInput(inputId = 'pbs_first',
                    label = 'Order PBS before CIS',
                    value=TRUE),
      checkboxGroupInput(inputId = "keepgrp",
                         label="Identify which samples to keep in the plot",
                         choices = list("SSM"="SSM",
                                        "MSM"="MSM",
                                        "LN"="LN",
                                        "TDLN"="TDLN",
                                        "PBS"="Untreated",
                                        "CIS"="Cisplatin"),
                         select=c('SSM', 'MSM', 'LN', 'TDLN', 
                                  'Untreated', 'Cisplatin'))
    ),
    mainPanel(
      plotOutput(outputId = "msmSsmHeatmap")
    )
  )
)

server <- function(input, output){
  # Hardcoded parameters [ Can Change ] 
  annotation_colors=list(
    LNstatus = c('TDLN'='#7fbc41', 'LN'='#de77ae'), # pink, green
    Treatment = c('Cisplatin'='#006d2c', 'Untreated'='#a1d99b'), # light-green, dark-green
    Celltype=c('SSM'='white', 'MSM'='black')  
  )
  
  # Hardcoded parameters [ Don't Change ] 
  celltype_order <- c('SSM', 'MSM')
  lnstatus_order <- c('LN', 'TDLN')
  treatment_order <- c('PBS', 'CIS')
  
  # Variance stabilize transform the genes and select GOI
  vst_assay <- vst(dat$cnt_mat, blind=T)
  vst_assay_goi <- vst_assay %>% 
    as.data.frame %>%
    tibble::rownames_to_column(., "id") %>%
    mutate(id=dat$ens2sym_ids[id]) %>%
    filter(!duplicated(id),
           !is.na(id)) %>%
    tibble::column_to_rownames(., "id")
  vst_assay_mat <- as.matrix(vst_assay_goi)
  storage.mode(vst_assay_mat) <- 'numeric'
  
  
  
  output$msmSsmHeatmap <- renderPlot({
    # Reactive values
    goi <- gsub(" " , "", strsplit(input$goi, ",")[[1]])
    if(!input$ssm_first) celltype_order <- rev(celltype_order)
    if(!input$ln_first) lnstatus_order <- rev(lnstatus_order)
    if(!input$pbs_first) treatment_order <- rev(treatment_order)
    
    
    if(any(!goi %in% rownames(vst_assay_goi))){
      warning(paste0("Genes not in your GOI: ", 
                     paste(goi[!goi %in% rownames(vst_assay_goi)], collapse="\n")), "\n")
    }
    
    
    # Merge matrices and decided whether to merge or separate samples
    vst_grp_goi_list <- split(as.data.frame(t(vst_assay_goi[goi,])), 
                              dat$condition)
    row_ord <- seq_along(goi) # Specify an order if you want to keep that gene-order
    
    if(input$merge_replicates){
      # Merge biological replicates into one group average
      vst_grp_goi <- vst_grp_goi_list %>%
        lapply(., colMeans) %>%
        do.call(rbind, .) %>% t
    } else {
      # Keep biological replicates separate and annotate accordingly
      vst_grp_goi <- vst_grp_goi_list %>% 
        do.call(rbind, .) %>% 
        t %>% as.data.frame %>%
        rename_with(., ~make.unique(gsub("\\..*", "", .)))
    }
    
    # Create the annotation data for the ComplexHeatmap
    annotation_col <- colnames(vst_grp_goi) %>% 
      gsub("\\..*", "", .) %>% 
      strsplit(., split="-|_") %>% 
      do.call(rbind, .) %>% as.data.frame  %>%
      rename_with(., ~c('LNstatus', 'Treatment', 'Celltype')) %>%
      mutate(Celltype = factor(Celltype, levels=celltype_order),
             LNstatus = factor(LNstatus, levels=lnstatus_order),
             Treatment = factor(Treatment, levels=treatment_order))
    treatment_anno_order <- c('Untreated', 'Cisplatin')
    if(treatment_order[1] == 'CIS') treatment_anno_order <-  rev(treatment_anno_order)
    levels(annotation_col$Treatment) <- treatment_anno_order
    order_idx <- with(annotation_col, order(Celltype, LNstatus, Treatment))
    
    
    # If no row order is given, do some custom ordering based on difference
    if(is.null(row_ord)) {
      row_ord <<- switch(order_type,
                         cis_pbs_diff=(order(vst_grp_goi[,'TDLN-CIS_MSM'] - vst_grp_goi[,'TDLN-PBS_MSM'])),
                         alphabetical=(order(rownames(vst_grp_goi))))
    }
    heatmaps <- list("matrix"=vst_grp_goi[row_ord, order_idx], 
                     "annotation_col"=annotation_col[order_idx,])
    
    # Filter out celltypes
    annotation_col <- heatmaps$annotation_col
    keep_idx <- apply(annotation_col[,1:3], 2, function(i){
      which(i %in% input$keepgrp)
    }) %>%
      Reduce(function(x,y) intersect(x,y), .)
    if(length(keep_idx) == 0 | is.null(keep_idx)) keep_idx <- c(1:nrow(annotation_col))
    
    # Z-scale the count matrix
    scaled_grp_goi <- t(apply(heatmaps$matrix[,keep_idx], 1, scale))
    
    # Prepare final ordering for heatmap
    annotation_col <- annotation_col[keep_idx,]
    annotation_col$split <- with(annotation_col, paste0(Celltype, LNstatus))
    annotation_col$split <- factor(annotation_col$split, levels=unique(annotation_col$split))
    
    # Plot heatmap
    gg_phm <- ComplexHeatmap::pheatmap(as.matrix(scaled_grp_goi), scale = 'none',
                                       color = colorRampPalette(c("#053061", "#4393c3", "#f7f7f7", 
                                                                  "#d6604d", "#67001f"))(20),
                                       annotation_col = annotation_col,
                                       column_split= annotation_col$split,
                                       annotation_colors = annotation_colors,
                                       fontsize_row = 14,show_colnames = FALSE,
                                       use_raster=FALSE, cluster_cols = FALSE, cluster_rows = FALSE
    ) %>% 
      ggplotify::as.ggplot(.) +
      theme_minimal(base_family = "Arial")
    
    gg_phm
  })
}

shinyApp(ui = ui, server = server)
